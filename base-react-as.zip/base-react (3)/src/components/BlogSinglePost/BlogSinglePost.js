import React, { useState, useRef, useEffect } from 'react';
import { Container, Card, CardContent, makeStyles, Grid, TextField, Button } from '@material-ui/core';
import QRCode from 'qrcode';
import QrReader from 'react-qr-reader';
import '../../styles/custom.css'
import { baseImagePath } from 'utility/utility';

export default (props) => {
  const regex = /(<([^>]+)>)/ig;
  var dateString = props.data.date;
  dateString = new Date(dateString).toUTCString();
  dateString = dateString.split(' ').slice(1, 4).join(' ');

  return (
    <>
      <main class="alphabet_school_main" id="single_post">
        <section class="as-banner">
          <div class="as_inner_wrap">
            <div class="container">
              <div class="row align-items-center">
                <div class="col-lg-10 offset-lg-1">
                  <div class="row">
                    <div class="col-lg-9">
                      <article class="custom_article banner_header allpost_header">
                        <h3 class="h3_title category_title">Category</h3>
                        <h2 class="h2_title allpost_title">{props.data.excerpt && props.data.excerpt.rendered.replace(regex, '')}</h2>
                      </article>
                      <div class="banner_header allpost_header">
                        <div class="avathor_img">
                          <img src={baseImagePath("icons/avathor.png")} class="custom_img"
                            alt="Avathor" />
                        </div>
                        <div class="author_name">by {props.data.slug}</div>
                        <div class="author_name">{dateString}</div>
                      </div>
                    </div>
                    <div class="col-lg-3">
                      <div class="category_list">
                        <ul class="nav custom_ul flex-column ">
                          <li class="nav-item custom_li">
                            <a href="#" class="nav-link singlePost_link">
                              <img src={baseImagePath("icons/instagram.png")} class="custom_img"
                                alt="instagram" />
                            </a>
                          </li>
                          <li class="nav-item custom_li">
                            <a href="#" class="nav-link singlePost_link">
                              <img src={baseImagePath("icons/linkedln.png")} class="custom_img"
                                alt="instagram" />
                            </a>
                          </li>
                          <li class="nav-item custom_li">
                            <a href="#" class="nav-link singlePost_link">
                              <img src={baseImagePath("icons/facebook.png")} class="custom_img"
                                alt="instagram" />
                            </a>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-lg-12">
                  <div class="single_post_banner">
                    <figure class="post_image rectangle_border">
                      <img src={baseImagePath("thumbnails/rectangle_6.png")}
                        class="custom_img rectangle_border" alt="Post" />
                    </figure>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section class="post_content_sec">
          <div class="pc_inner_wrap">
            <div class="container">
              <div class="row">
                <div class="col-lg-10 offset-lg-1">
                  <div class="row">
                    <div class="col-lg-9">
                      <article class="custom_article banner_header allpost_description">
                        <p class="para_style post_info">
                          {props.data.content && props.data.content.rendered.replace(regex, '')}
                        </p>
                      </article>
                      <div class="subscribe_content">
                        <div class="sc_wrap">
                          <div class="inner_sc_wrap">
                            <div class="avathor_img">
                              <img src={baseImagePath("icons/avathor.png")} class="custom_img"
                                alt="Avathor" />
                            </div>
                            <div class="author_name">by {props.data.slug}</div>
                            <p class="para_style post_avathor_content">
                              {props.data.excerpt && props.data.excerpt.rendered.replace(regex, '')}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-lg-3">
                      <div class="category_list">
                        <header class="margin_B30 text-right text_right">
                          <a href="javascipt: void(0);" class="skip_anger">Skip to part</a>
                        </header>
                        <ul class="nav custom_ul flex-column padding_R35">
                          <li class="nav-item custom_li">
                            <a href="#" class="nav-link section_link margin_B30">Section 1</a>
                          </li>
                          <li class="nav-item custom_li">
                            <a href="#" class="nav-link section_link margin_B30">Section 2</a>
                          </li>
                          <li class="nav-item custom_li">
                            <a href="#" class="nav-link section_link margin_B30">Section 3</a>
                          </li>
                          <li class="nav-item custom_li">
                            <a href="#" class="nav-link section_link margin_B30">Section 4</a>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section class="most_recent_sec">
          <div class="mr_wrap margin_T100">
            <div class="container">
              <div class="row">
                <div class="col-lg-12">
                  <div class="top_title">
                    <header class="mr_mainHeader top_mainHeader ">
                      <h3 class="h2_title top_inner_title animate__animated animate__zoomIn">Related Posts
                      </h3>
                      <a href="javascript: void(0)" class="view_angar">View all posts </a>
                    </header>
                  </div>
                </div>
              </div>
              <section class="category_grid">
                <div class="row">
                  <div class="col-lg-4 margin_T42">
                    <div class="grid_card left_content margin_T40 padding_R16 mt-5">
                      <div class="left_inner">
                        <div class="sp_image grid_image">
                          <img src={baseImagePath("thumbnails/rectangle_5.png")}
                            class="custom_img rectangle_border" alt="FEATURED IMAGE" />
                        </div>
                      </div>
                      <div class="most_recent_header">
                        <article class="featured_category custom_article">
                          <h4 class="h4_title category_title">Category</h4>
                          <h3 class="h3_title mr_title">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam elementum.
                          </h3>
                        </article>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 margin_T42">
                    <div class="grid_card left_content margin_T40 padding_R16 mt-5">
                      <div class="left_inner">
                        <div class="sp_image grid_image">
                          <img src={baseImagePath("thumbnails/rectangle_5.png")}
                            class="custom_img rectangle_border" alt="FEATURED IMAGE" />
                        </div>
                      </div>
                      <div class="most_recent_header">
                        <article class="featured_category custom_article">
                          <h4 class="h4_title category_title">Category</h4>
                          <h3 class="h3_title mr_title">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam elementum.
                          </h3>
                        </article>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4 margin_T42">
                    <div class="grid_card left_content margin_T40 padding_R16 mt-5">
                      <div class="left_inner">
                        <div class="sp_image grid_image">
                          <img src={baseImagePath("thumbnails/rectangle_5.png")}
                            class="custom_img rectangle_border" alt="FEATURED IMAGE" />
                        </div>
                      </div>
                      <div class="most_recent_header">
                        <article class="featured_category custom_article">
                          <h4 class="h4_title category_title">Category</h4>
                          <h3 class="h3_title mr_title">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam elementum.
                          </h3>
                        </article>
                      </div>
                    </div>
                  </div>
                </div>
              </section>
            </div>
          </div>
        </section>
      </main>
    </>
  );
}
