import React, { useState, useRef, useEffect } from 'react';
import { Container, Card, CardContent, makeStyles, Grid, TextField, Button } from '@material-ui/core';
import QRCode from 'qrcode';
import QrReader from 'react-qr-reader';
import '../../styles/custom.css'
import { baseImagePath } from 'utility/utility';
import { routes } from 'utility/constants/constants';

export default (props) => {
  debugger;
  console.log(props.categories_list)
  const regex = /(<([^>]+)>)/ig;
  return (
    <>
      <main class="alphabet_school_main" id="view_all_post">
        <section class="as-banner">
          <div class="as_inner_wrap">
            <div class="container">
              <div class="row align-items-center">
                <div class="col-lg-10 offset-lg-1">
                  <article class="custom_article banner_header allpost_header">
                    <h2 class="h2_title allpost_title animate__animated animate__zoomIn animate__fadeIn">All
                      Posts{props.categories}</h2>
                  </article>
                  {/*<div class="category_list">
                    <ul class="nav custom_ul row">
                      <li class="nav-item custom_li col">
                        <a href="#" class="nav-link allPost_link ">Category 1</a>
                      </li>
                      <li class="nav-item custom_li col">
                        <a href="#" class="nav-link allPost_link">Category 2</a>
                      </li>
                      <li class="nav-item custom_li col">
                        <a href="#" class="nav-link allPost_link">Category 3</a>
                      </li>
                      <li class="nav-item custom_li col">
                        <a href="#" class="nav-link allPost_link">Category 4</a>
                      </li>
                    </ul>
                  </div> */}
                </div>
              </div>
            </div>
          </div>
        </section>
        <section class="category_grid">
          <div class="cg_inner_wrap">
            <div class="container">
              <div class="row">
                {props.categories_list && props.categories_list.map((a, i) => (
                  <div class="col-lg-4 margin_T60">
                    <a className="d-inline-block" onClick={() => { props.getSinglePost(a.id); props.history.push(routes.SINGLE_POST) }}>
                      <div class="grid_card left_content margin_T40 padding_R16 mb-3">
                        <div class="left_inner">
                          <div class="ri_image grid_image">
                            <img src={baseImagePath("thumbnails/rectangle_5.png")}
                              class="custom_img rectangle_border" alt="FEATURED IMAGE" />
                          </div>
                          <div class="author_name pt-2">by <span className="fst-italic">{a.title && a.title.rendered}</span></div>
                        </div>
                        <div class="most_recent_header">
                          <article class="featured_category custom_article mt-3">
                            <h4 class="h4_title category_title">{a.taxonomy}</h4>
                            <div class="h3_title mr_title">
                              {a.content && a.content.rendered.replace(regex, '')}
                            </div>
                          </article>
                        </div>
                      </div>
                    </a>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>
      </main>
    </>
  );
}
