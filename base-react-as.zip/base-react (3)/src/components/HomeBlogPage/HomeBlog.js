import React, { useState, useRef, useEffect } from 'react';
import { Container, Card, CardContent, makeStyles, Grid, TextField, Button } from '@material-ui/core';
import QRCode from 'qrcode';
import QrReader from 'react-qr-reader';
import '../../styles/custom.css'
import { baseImagePath } from 'utility/utility';
import { getSinglePost } from 'api/authAPI';
import { Link } from 'react-router-dom';

export default (props) => {
  return (  
    <>
      <main class="alphabet_school_main" id="main_wrapper">
        <section class="as-banner margin_30">
          <div class="as_inner_wrap">
            <div class="container">
              <div class="row align-items-center">
                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12">
                  <article class="custom_article banner_header">
                    <h2 class="h2_title animate__animated animate__zoomIn">The aLphabet international school’s <span>blog{props.data.id}</span></h2>
                  </article>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section class="featured_sec">
          <div class="fs_wrap">
            <div class="container">
              <div class="row">
                <div class="col-lg-12">
                  <div class="top_title">
                    <header class="fs_mainHeader top_mainHeader">
                      <h3 class="h2_title top_inner_title">Featured</h3>
                    </header>
                  </div>
                </div>
              </div>
              <div class="col_wrapper">
                <div class="row">
                  <div class="col-lg-6">
                    <div class="fs_left_content left_content">
                      <div class="left_inner">
                        <header class="featured_header">
                          <h3 class="h3_title featured_title">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam elementum.
                          </h3>
                          <div class="author_name">by John Doe {props.categories}</div>
                        </header>
                        <article class="featured_category custom_article">
                          <h4 class="h4_title category_title">Category</h4>
                          <p class="para_style category_info">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque mauris
                            elit, aliquet ac malesuada vel, suscipit ac ipsum. Curabitur elementum
                            eleifend justo, non rhoncus lectus cursus sed.
                          </p>
                        </article>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-6">
                    <div class="fs_right_content right_content">
                      <div class="ri_image grid_image">
                        <img src={baseImagePath("thumbnails/rectangle_1.png")} class="custom_img"
                          alt="FEATURED IMAGE" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section class="most_recent_sec">
          <div class="mr_wrap margin_T100">
            <div class="container">
              <div class="row">
                <div class="col-lg-12">
                  <div class="top_title">
                    <header class="mr_mainHeader top_mainHeader ">
                      <h3 class="h2_title top_inner_title animate__animated animate__zoomIn">Most recent
                        Posts</h3>
                      <Link to='/view-all-post' href="javascript: void(0)" class="view_angar">View all posts </Link>
                    </header>
                  </div>
                </div>
              </div>
              <div class="col_wrapper">
                <div class="row">
                  <div class="col-lg-7">
                    <div class="mr_left_content left_content margin_T40 padding_R16">
                      <div class="left_inner">
                        <div class="ri_image grid_image">
                          <img src={baseImagePath("thumbnails/Rectangle_2.png")}
                            class="custom_img rectangle_border" alt="FEATURED IMAGE" />
                        </div>
                      </div>
                      <div class="most_recent_header">
                        <div class="author_name">by John Doe</div>
                        <article class="featured_category custom_article">
                          <h4 class="h4_title category_title">Category</h4>
                          <h3 class="h3_title mr_title">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam elementum.
                          </h3>
                          <p class="para_style category_info">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque mauris
                            elit, aliquet ac malesuada vel, suscipit ac ipsum. Curabitur elementum
                            eleifend justo, non rhoncus lectus cursus sed.
                          </p>
                        </article>
                      </div>
                    </div>
                    <div class="mr_left_content left_content margin_T40 padding_R16">
                      <div class="left_inner">
                        <div class="ri_image grid_image">
                          <img src={baseImagePath("thumbnails/Rectangle_2.png")}
                            class="custom_img rectangle_border" alt="FEATURED IMAGE" />
                        </div>
                      </div>
                      <div class="most_recent_header">
                        <div class="author_name">by John Doe</div>
                        <article class="featured_category custom_article">
                          <h4 class="h4_title category_title">Category</h4>
                          <h3 class="h3_title mr_title">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam elementum.
                          </h3>
                          <p class="para_style category_info">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque mauris
                            elit, aliquet ac malesuada vel, suscipit ac ipsum. Curabitur elementum
                            eleifend justo, non rhoncus lectus cursus sed.
                          </p>
                        </article>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-5">
                    <div class="grid_card left_content margin_T40">
                      <div class="left_inner">
                        <div class="ri_image grid_image">
                          <img src={baseImagePath("thumbnails/rectangle_3.png")}
                            class="custom_img rectangle_border" alt="FEATURED IMAGE" />
                        </div>
                      </div>
                      <div class="most_recent_header">
                        <div class="author_name">by John Doe</div>
                        <article class="featured_category custom_article">
                          <h4 class="h4_title category_title">Category</h4>
                          <h3 class="h3_title mr_title">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam elementum.
                          </h3>
                        </article>
                      </div>
                    </div>
                    <div class="grid_card left_content margin_T40">
                      <div class="left_inner">
                        <div class="ri_image grid_image">
                          <img src={baseImagePath("thumbnails/rectangle_3.png")}
                            class="custom_img rectangle_border" alt="FEATURED IMAGE" />
                        </div>
                        <div class="author_name">by John Doe</div>
                      </div>
                      <div class="most_recent_header">
                        <article class="featured_category custom_article">
                          <h4 class="h4_title category_title">Category</h4>
                          <h3 class="h3_title mr_title">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam elementum.
                          </h3>
                        </article>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section class="suggest_sec">
          <div class="sg_wrap margin_T100">
            <div class="container">
              <div class="row">
                <div class="col-lg-12">
                  <div class="top_title">
                    <header class="fs_mainHeader top_mainHeader">
                      <h3 class="h2_title top_inner_title animate__animated animate__zoomIn">Suggested
                        Reads</h3>
                    </header>
                  </div>
                </div>
              </div>
              <div class="col_wrapper">
                <div class="dynamic_row suggest_row">
                  <div class="row align-items-center">
                    <div class="col-lg-4">
                      <div class="suugest_right grid_image">
                        <img src={baseImagePath("thumbnails/rectangle_4.png")}
                          class="custom_img rectangle_border" alt="FEATURED IMAGE" />
                      </div>
                    </div>
                    <div class="col-lg-8">
                      <div class="suugest_left">
                        <div class="author_name">by John Doe</div>
                        <article class="featured_category custom_article w-75">
                          <h4 class="h4_title category_title">Category</h4>
                          <h3 class="h3_title mr_title">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam elementum.
                          </h3>
                        </article>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="dynamic_row suggest_row">
                  <div class="row align-items-center">
                    <div class="col-lg-4">
                      <div class="suugest_right grid_image">
                        <img src={baseImagePath("thumbnails/rectangle_4.png")}
                          class="custom_img rectangle_border" alt="FEATURED IMAGE" />
                      </div>
                    </div>
                    <div class="col-lg-8">
                      <div class="suugest_left">
                        <div class="author_name">by John Doe</div>
                        <article class="featured_category custom_article w-75">
                          <h4 class="h4_title category_title">Category</h4>
                          <h3 class="h3_title mr_title">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam elementum.
                          </h3>
                        </article>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="dynamic_row suggest_row">
                  <div class="row align-items-center">
                    <div class="col-lg-4">
                      <div class="suugest_right grid_image">
                        <img src={baseImagePath("thumbnails/rectangle_4.png")}
                          class="custom_img rectangle_border" alt="FEATURED IMAGE" />
                      </div>
                    </div>
                    <div class="col-lg-8">
                      <div class="suugest_left">
                        <div class="author_name">by John Doe</div>
                        <article class="featured_category custom_article w-75">
                          <h4 class="h4_title category_title">Category</h4>
                          <h3 class="h3_title mr_title">
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam elementum.
                          </h3>
                        </article>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section class="subscripe_sec margin_T120 mb-5">
          <div class="inner_wrapper">
            <div class="container">
              <div class="row">
                <div class="col-lg-12">
                  <div class="subscribe_content">
                    <div class="sc_wrap">
                      <div class="inner_sc_wrap">
                        <article class="custom_article sub_article">
                          <h3 class="h3_title">Subscribe to aLphabet international school’s blog!</h3>
                          <p class="para_style sub_info">It’s free!</p>
                        </article>
                        <button class="primary_btn signup_btn font_weight_bold">Sign up now!</button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
    </>
  );
}
