import React, { useState, useEffect } from "react";
import { baseImagePath } from "utility/utility";
import { Link } from "react-router-dom";
import "./layout.scss"
import * as actions from "redux/actions/index";
import { routes } from "utility/constants/constants";
import { Container, Nav, Navbar, NavDropdown } from "react-bootstrap";
import { IoIosArrowDown } from 'react-icons/io';
import { RouteLink, Ul } from "../../../utility/styledComponents/styledComponents";
import styled, { css } from 'styled-components'


export const Header = (props) => {

  // const {setStyle} = props;

  // useEffect(() => { debugger;
  //   setStyle();
  // }, []);

  const RouteLink = styled(Link)`
  color: #ffffff;
  background-color: ${props.mainTitle}
  text-decoration: none !important;
`

  const [headerWrap, setHeaderWrap] = useState(false)

  const navbarBackgroundChange = () => {
    if (window.scrollY >= 60) {
      return setHeaderWrap(true)
    }
    else {
      return setHeaderWrap(false)
    }
  }
  window.addEventListener('scroll', navbarBackgroundChange)
  const currentPath = props.history.location.pathname

  let headerTabsContent = (
    <>
      <header class="custom_header" id="site_header">
        <div class="ds-header" id="site-header">
          <div class="container">
            <div class="ds-header-inner">
              <a href="index.html" class="ds-logo">
                <img src={baseImagePath('icons/logo_new.png')} class="custom_img"
                  alt="Alphabet Internation School" />
              </a>
              <a href="javascript: void(0);" class="menubar">
                <img src={baseImagePath('icons/logo_new.png')} class="custom_img" alt="IB Logo" />
              </a>
              <ul class="ds-social custom_ul">
                <li class="custom_li header_li">
                  <Link exact to='/home-blog' href="javascript: void(0);" class={currentPath === routes.HOME_BLOG ? "header_anger active" : "header_anger "}>Home</Link>
                </li>
                <li class="custom_li header_li">
                  <Link exact to="/single-post" class="header_anger" href="javascript: void(0);">About Us</Link>
                </li>
                <li class="custom_li header_li">
                <Link exact to="/view-all-post" class="header_anger " href="javascript: void(0);">IB at
                  aLphabet</Link>
                </li>
                <li class="custom_li header_li"><a href="javascript: void(0);" class="header_anger">Programs</a>
                </li>
                <li class="custom_li header_li"><a href="javascript: void(0);"
                  class="header_anger">Admissions</a>
                </li>
                <li class="custom_li header_li"><a href="javascript: void(0);" class="header_anger">Gallery</a>
                </li>
                <li class="custom_li header_li"><a href="javascript: void(0);" class="header_anger">Contact
                  Us</a>
                </li>
                <li class="custom_li header_li"><a href="javascript: void(0);" class="header_anger active">Blog
                </a>
                </li>
                <li class="custom_li header_li mobile_view">
                  <a href="javascript: void(0);" class="header_anger ib_img">
                    <img src={baseImagePath('icons/IB.png')} class="custom_img" alt="IB Logo" />
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </header>
    </>
  );


  return headerTabsContent;
};