import React from "react";
import HomeBlogContainer from "../containers/HomeBlog/HomeBlogContainer";
import { Switch, Route, Redirect } from "react-router-dom";
import { routes } from "../utility/constants/constants";
import BlogSinglePostContainer from "containers/BlogSinglePost/BlogSinglePostContainer";
import ViewAllPostContainer from "containers/ViewAllPost/ViewAllPostContainer";

export default () => {
  return (
    <Switch>
      <Route exact path={routes.HOME_BLOG} component={HomeBlogContainer} />
      <Route exact path={routes.SINGLE_POST} component={BlogSinglePostContainer} />
      <Route exact path={routes.VIEW_ALL_POST} component={ViewAllPostContainer} />
      <Route exact path="*" component={() => <Redirect to={routes.HOME_BLOG} />} />
    </Switch>
  );
};
