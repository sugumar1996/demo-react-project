import React from "react";
import { Switch, Route, Redirect } from "react-router-dom";
import { routes } from "../utility/constants/constants";
import Login from "containers/HomeBlog/HomeBlogContainer";

export default () => {
  return (
    <Switch>
      <Route exact path={routes.ROOT} component={Login} />
      <Route exact path="*" component={() => <Redirect to={routes.ROOT} />} />
    </Switch>
  );
};
