import React, { Component } from 'react';
import { useSelector } from "react-redux";
import * as actions from '../../redux/actions/index';
import { connect } from 'react-redux';
import HomeBlog from "components/HomeBlogPage/HomeBlog";
import { Container } from "react-bootstrap";

class HomeBlogContainer extends Component {

  constructor(props) {
    super(props);

    this.state = {

    }
  }
  getSinglePost = (id) => { 
    this.props.getSinglePost(id);
}


  render() {
    return (
      <>
        <HomeBlog
        {...this.props}
        // getSinglePost={this.getSinglePost}
        data={this.props.data}
        categories={this.props.categories}
        />
      </>
    )
  }
}


const mapStateToProps = (state) => { 
  return {
    data: state.authReducer.data,
    categories: state.authReducer.categories
  }
};

const mapDispatchToProps = (dispatch) => {
  return {
    getSinglePost: (id) => dispatch(actions.getSinglePost(id))
    
  }
}


export default connect(mapStateToProps, mapDispatchToProps)(HomeBlogContainer);
