import React, { Component } from 'react';
import { useSelector } from "react-redux";
import * as actions from '../../redux/actions/index';
import { connect } from 'react-redux';
import ViewAllPost from 'components/ViewAllPost/ViewAllPost';
import { routes } from 'utility/constants/constants';

class ViewAllPostContainer extends Component {

  constructor(props) {
    super(props);

    this.state = {

    }
  }
  componentDidMount() {
    this.props.getCategoriesList();
  }
  getCategoriesList = () => {
    this.props.getCategoriesList();
  }
  getSinglePost = (id) => {debugger;
    this.props.getSinglePost(id)
  }
  render() {
    return (
      <>
        <ViewAllPost
          {...this.props}
          getCategoriesList={this.getCategoriesList}
          categories_list={this.props.categories_list}
          getSinglePost={this.getSinglePost}
        />
      </>
    )
  }
}


const mapStateToProps = (state) => {
  return {
    categories_list: state.authReducer.categories_list,
  }
};

const mapDispatchToProps = (dispatch) => {
  return {
    getCategoriesList: () => dispatch(actions.getCategoriesList()),
    getSinglePost: (id) => dispatch(actions.getSinglePost(id))
  }
}


export default connect(mapStateToProps, mapDispatchToProps)(ViewAllPostContainer);
