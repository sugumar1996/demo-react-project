import React, { Component } from 'react';
import { useSelector } from "react-redux";
import * as actions from '../../redux/actions/index';
import { connect } from 'react-redux';
import BlogSinglePost from "components/BlogSinglePost/BlogSinglePost.js";
import { Container } from "react-bootstrap";

class BlogSinglePostContainer extends Component {

  constructor(props) {
    super(props);

    this.state = {

    }
  }
  getSinglePost = (id) => {
    this.props.getSinglePost(id);
}
componentDidMount = () => { 
  this.props.getSinglePost(this.id);
}
  render() {
    return (
      <>
        <BlogSinglePost
        {...this.props}
        getSinglePost={this.getSinglePost}
        singlePostData={this.props.singlePostData}
        data={this.props.data}
        />
      </>
    )
  }
}


const mapStateToProps = (state) => { 
  return {
    singlePostData: state.authReducer.singlePostData,
    data: state.authReducer.data,
  }
};

const mapDispatchToProps = (dispatch) => {
  return {
    getSinglePost: (id) => dispatch(actions.getSinglePost(id))
  }
}


export default connect(mapStateToProps, mapDispatchToProps)(BlogSinglePostContainer);
